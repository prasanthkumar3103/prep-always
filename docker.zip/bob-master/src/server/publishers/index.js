module.exports = [
  require('./github-commit-status'),
  require('./notify'),
  require('./slack'),
  require('./stdout')
];
