module.exports = {
  ROOT: 0,
  READ: 1 << 0,
  WRITE: 1 << 1,
  ADMIN: 1 << 2
};
