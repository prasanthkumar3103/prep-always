module.exports = {
  PENDING: 'pending',
  CLAIMED: 'claimed',
  PULLING: 'pulling',
  BUILDING: 'building',
  PUSHING: 'pushing',
  SUCCEEDED: 'succeeded',
  CANCELLED: 'cancelled',
  FAILED: 'failed'
};
