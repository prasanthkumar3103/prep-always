import {render} from 'react-dom';
import React from 'react';
import RootLayout from '../components/root/layout';

render(<RootLayout />, document.getElementById('root'));
