Development
===========

Install dependencies
--------------------

With [Node.js](http://nodejs.org) and npm installed, run:

```bash
npm run deps
```

Run tests
=========

```sh
gulp watch
```