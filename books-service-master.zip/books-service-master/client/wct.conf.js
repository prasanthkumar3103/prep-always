module.exports = {
    verbose: false,
    plugins: {
        local: {
            browsers: ['chrome']
        }
    }
};